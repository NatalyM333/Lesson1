<?php
////1
// $input='hello_world';
// $str = str_replace('_','',$input);
// echo $str;

////2
// $input='привіт світ';
// $arr=explode(' ',$input);
// $input='';
// for($i=0;$i<count($arr);$i++)
// {
// $tmp=   str_split ( $arr[$i] , 2 );
//     for($j=count($tmp)-1;$j>=0;$j--)
//     $input=$input . $tmp[$j];
//     $input= $input . ' ';

// }
// echo $input;

////3
//  $input='helloh';
//  if($input[0]==$input[strlen($input)-1])
//  $input=substr_replace (  $input , strtoupper($input[0]) , 0 , 1) . $input;
//  else
//  $input='The' . ' ' . substr_replace (  $input , strtoupper($input[0]) , 0 , 1);
//  echo $input;
