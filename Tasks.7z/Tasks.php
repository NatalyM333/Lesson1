<?php
////1
// $minute=30;
// if($minute>=0&&$minute<15)
// {
//     echo'first';
// }
// else if($minute>=15&&$minute<30)
// {
//     echo'second';
// }
// else if($minute>=30&&$minute<45)
// {
//     echo'third';
// }
// else if($minute>=45&&$minute<60)
// {
//     echo'fouth';
// }
// else if($minute>=60||$minute<0)
// {
//    throw new InvalidArgumentExeption('InvalidArgumentExeption');
// }

////2
// $year=2017;
// if($year<2021||$year>=1900)
// {
//         if($year%4==0){
//             if($year%100!=0){
//             echo'true';
//             }
//             else{
//                 echo'false';
//             }
//         }
//         else{
//             echo'false';
//         }
//  }
//  else{
//     throw new InvalidArgumentExeption('InvalidArgumentExeption');
//  }
 ////3
//  $input="123321";
// if(strlen($input)==6)
// {
//  if($input[0]+$input[1]+$input[2]==$input[3]+$input[4]+$input[5]){
//      echo'true';
//  }
//  else
//  echo'false';
// }
// else
// throw new InvalidArgumentExeption('InvalidArgumentExeption');